﻿// See https://aka.ms/new-console-template for more information
using DB_dll;
using DB_dll.Tables;
using System;



class Program
{

    static void Main()
    {
        Console.WriteLine("Hello, World!");


        List<DB_dll.Tables.Departament> dep = Departament.GetDepartments();

        for (int i = 0; i< dep.Count; i++)
        {
            Console.WriteLine(dep[i].DepartamentName + "\n" + dep[i].Description);
            Console.WriteLine("\n");
        }

        //Departament departament = new Departament("Administrativ", "Departamentul administrativ este cel care are responsabilitatea de a cuprinde restul departamentelor. Principalele sale functii sunt organizarea, planificarea, directia, coordonarea, controlul si evaluarea.");

        //Dictionary<string, object> dep2 = new Dictionary<string, object>
        //{
        //    { "NumeDepartament", "Marketing" },
        //    { "Description", "Se ocupa de promovarea companiei pe plan intern si international" },
        //};


        //Tabel.AddValueTable("Departament", dep2);

    }
}
