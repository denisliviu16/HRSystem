﻿using System;
using System.Collections.Generic;
using System.Data.SqlClient;
using System.Linq;
using System.Text;
using System.Threading.Tasks;



namespace DB_dll.Db
{
    public static class DbConnection
    {
        private static readonly string _connectionString= "Server=DESKTOP-N916831\\SQLEXPRESS; Database=HR_BUN; Integrated Security=true";

        public static SqlConnection GetConnection()
        {
            return new SqlConnection(_connectionString);
        }



    }
}
