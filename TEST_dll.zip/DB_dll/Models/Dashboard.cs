﻿using System;
using System.Collections.Generic;
using System.Data.Common;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using DB_dll.Db;

namespace DB_dll.Models
{
    //public class Dashboard : Db.DbConnection
    //{
    //    private DateTime startDate;
    //    private DateTime endDate;
    //    private int numberDays;


    //}
}
