﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace DB_dll.Tables
{
    public class EmployeesCategory : Tabel
    {

        public int ID{ get; }
        public int DepartamentID{ set; get; }
        public string CategoryName { set; get; }
        public string Description { set; get; }
        public EmployeesCategory(int mDepartamentID,string mCategoryName,string mDescription) 
        {

            DepartamentID = mDepartamentID;
            CategoryName = mCategoryName;
            Description = mDescription;
        }

       
    }
}
