﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace DB_dll.Tables
{
    internal class Payroll : Tabel
    {
        public int ID {  get; }
        public int EmployeeID { get; set; }
        public double Salariu {  get; set; }
        public DateTime Payday { get; set; }
        public Payroll(int mEmployeeID,double mSalariu, DateTime mPayday) 
        {
            EmployeeID = mEmployeeID;
            Salariu = mSalariu;
            Payday = mPayday;
        }
    }
}
