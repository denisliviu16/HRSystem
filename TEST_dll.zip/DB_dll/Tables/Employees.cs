﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace DB_dll.Tables
{
    public class Employees : Tabel
    {
        public int ID { get; }

        public int FunctionID { get; set; }
        public int UserTypeID { set; get; }
        public string Name { get; set; }
        public string SurName { get; set; }
        public DateTime BirthDate { get; set; }
        public string email { get; set; }
        public string Contact { get; set; }

        public bool Gender { get; set; } //0 male ; 1 female

        public string Address { get; set; }
        public DateTime JoiningDate { get; set; }

        public DateTime LeavingDate { get; set; }


        public Employees(int mFunctionID,int mUserTypeID, string mName,string mSurName,DateTime mBirthDate,string mEmail,
            string mContact,bool mGender, string mAddress,DateTime mJoiningDate,DateTime mLeavingDate) 
        {
                
            this.FunctionID = mFunctionID;
            this.UserTypeID = mUserTypeID;
            this.Name = mName;
            this.SurName = mSurName;
            this.BirthDate = mBirthDate;
            email = mEmail;
            Contact = mContact;
            Gender = mGender;
            Address = mAddress;
            JoiningDate = mJoiningDate;
            LeavingDate = mLeavingDate;
        }



    }
}
