﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace DB_dll.Tables
{
    internal class Tasks : Tabel
    {
        public int ID { get;}
        public int TaskTypeID { get; set; }
        public int EmployeeID { get; set; }

        public DateTime StartDate { get; set; }
        public DateTime EndDate { get; set; }
        public bool Active {  get; set; }
        public Tasks(int mTaskTypeID, int mEmployeeID, DateTime mStartDate, DateTime mEndDate,bool mActive) 
        { 
            TaskTypeID = mTaskTypeID;
            EmployeeID = mEmployeeID;
            StartDate = mStartDate;
            EndDate = mEndDate;
            Active = mActive;

        }

    }
}
