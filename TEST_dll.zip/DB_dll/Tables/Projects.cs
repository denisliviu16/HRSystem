﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace DB_dll.Tables
{
    internal class Projects : Tabel
    {
        public int ID {  get; }
        public string ProjectName { get; set; }
        public string Description { get; set; }

        public DateTime StartDate { get; set; }
        public DateTime EndDate { get; set; }
        public bool Active {  get; set; }

        public Projects(string mProjectName, string mDescription,DateTime mStartDate,DateTime mEndDate,bool mActive) 
        {
            ProjectName=mProjectName;
            Description=mDescription;
            StartDate=mStartDate;
            EndDate=mEndDate;
            Active=mActive;
        }
    }
}
