﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace DB_dll.Tables
{
    public class UserType : Tabel
    {
        public int ID { get; }
        public string TipUser { set; get; }


        UserType( string mtipUser)
        {
            TipUser = mtipUser;
        }
    }
}
