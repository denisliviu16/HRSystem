﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace DB_dll.Tables
{
    internal class ReasonHoliday : Tabel
    {
        public int ID { get; }
        public string ReasonName { get;set;}

        public ReasonHoliday(string mReasonName)
        { ReasonName = mReasonName; }

    }
}
