﻿using System;
using System.Collections.Generic;
using System.Data;
using System.Data.SqlClient;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

using DB_dll.Db;
using DB_dll.Tables;

namespace DB_dll.Tables

{
    public class Departament : Tabel
    {


        public int ID { get; }
        public string DepartamentName { set; get; }
        public string Description { set; get; }


        public Departament(string mDepartamentName, string mDescription)
        {
            DepartamentName = mDepartamentName;
            Description = mDescription;
        }

        public Departament() { }
        public static List<Departament> GetDepartments()
        {
            List<Departament> departments = new List<Departament>();
            using (SqlConnection connection = DbConnection.GetConnection())
            {
                connection.Open();
                string query = "SELECT * FROM Departament";
                using (SqlCommand command = new SqlCommand(query, connection))
                using (SqlDataReader reader = command.ExecuteReader())
                {
                    while (reader.Read())
                    {
                        Departament department = new Departament(reader[1].ToString(), reader[2].ToString());
                        departments.Add(department);
                    }
                }
            }
            return departments;
        }

        
    }
}















//public static void AddDepartment(Departament dep)
//{
//    string insertCommand = "INSERT INTO Departament (NumeDepartament, Description) VALUES (@Value1, @Value2)";

//    using (SqlConnection connection = DbConnection.GetConnection())
//    {
//        connection.Open();

//        using (SqlCommand command = new SqlCommand(insertCommand, connection))
//        {
//            // Parametrii pentru valorile pe care doriți să le adăugați
//            command.Parameters.AddWithValue("@Value1", dep.DepartamentName);
//            command.Parameters.AddWithValue("@Value2", dep.Description);

//            // Executați comanda de inserție
//            int rowsAffected = command.ExecuteNonQuery();

//            if (rowsAffected > 0)
//            {
//                Console.WriteLine("Inserare reușită!");
//            }
//            else
//            {
//                Console.WriteLine("Inserarea a eșuat.");
//            }
//        }
//    }
//}