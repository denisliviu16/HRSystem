﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace DB_dll.Tables
{
    internal class LeaveReason : Tabel
    {
        public int ID {  get; }
        public string ReasonName { get; set; }
        public string ReasonDescription { get; set;}

        public double MoneyPerHour {  get; set; }

        public LeaveReason(string mReasonName,string mReasonDescription,double mMoneyPerHour)
        {
            ReasonName = mReasonName;
            ReasonDescription = mReasonDescription;
            MoneyPerHour = mMoneyPerHour;

        }
    }
}
