﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace DB_dll.Tables
{
    class Attendance:Tabel
    {
        public int ID { get; }

        public int EmployeeID { get; set; }
        public DateTime DateToday { set; get; }

        public DateTime SignIN { set; get; }
        public DateTime SignOUT { set; get; }

        public double WorkingHours { set; get; }
        public bool Active { set; get; } //0 daca nu participa, 1 daca participa


        public Attendance(int mEmployeeID, DateTime mDateToday, DateTime mSignIN, DateTime mSignOUT, double mWorkingHours,bool mActive )
        {
            EmployeeID = mEmployeeID;
            DateToday = mDateToday;
            SignIN = mSignIN;
            SignOUT = mSignOUT;
            WorkingHours = mWorkingHours;
            Active = mActive;

        }
    }
}
