﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace DB_dll.Tables
{
    public class Functions : Tabel
    {
  
        public int ID{ get; }
        public int CategoryID { set; get; }
        public string FunctionName { set; get; }

        Functions(int mCategoryID,string mFunctionName) 
        {
            CategoryID = mCategoryID;
            FunctionName = mFunctionName;
        }
    }
}
