﻿using System;
using System.Collections.Generic;
using System.Data.SqlClient;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using DB_dll.Db;

namespace DB_dll.Tables
{
    public enum NumeTabel
    {
        Departament,
        EmployeesCategory,
        Functions,
        UserType,
        Gender,
        Employees,
        Attendance,
        Holiday,
        ReasonHoliday,
        Leaves,
        LeaveReason,
        ProjectDuties,
        Projects,
        Tasks,
        TasksTypes,
        Payroll
    }
    public class Tabel
    {
        public Tabel() {}
        public List<Tabel*> GetInstance(NumeTabel tabelName) {

            List<Departament> departments = new List<Departament>();
            using (SqlConnection connection = DbConnection.GetConnection())
            {
                connection.Open();
                string query = "SELECT * FROM "+ tabelName;
                using (SqlCommand command = new SqlCommand(query, connection))
                using (SqlDataReader reader = command.ExecuteReader())
                {
                    while (reader.Read())
                    {
                        Departament department = new Departament(reader[1].ToString(), reader[2].ToString());
                        departments.Add(department);
                    }
                }
            }
            return departments;
        }



        public static void AddValueTable(NumeTabel tabelName, Dictionary<string, object> columnValues)
        {
            using (SqlConnection connection = DbConnection.GetConnection())
            {
                connection.Open();

                string insertCommand = $"INSERT INTO {tabelName.ToString()} (";
                string values = "";
                int paramCount = 0;

                using (SqlCommand command = new SqlCommand())
                {
                    command.Connection = connection;

                    foreach (var kvp in columnValues)
                    {
                        insertCommand += kvp.Key + ", ";
                        values += $"@Value{paramCount}, ";
                        command.Parameters.AddWithValue($"@Value{paramCount}", kvp.Value);
                        paramCount++;
                    }

                    insertCommand = insertCommand.TrimEnd(',', ' ') + ") VALUES (" + values.TrimEnd(',', ' ') + ")";

                    command.CommandText = insertCommand;

                    // Executați comanda de inserție
                    int rowsAffected = command.ExecuteNonQuery();

                    if (rowsAffected > 0)
                    {
                        Console.WriteLine("Inserare reusita!"); ///aici voi face o fereastra pop-up in apk
                        //daca reuseste inserarea, apare fereastra cu succes, daca nu cu fail
                    }
                    else
                    {
                        Console.WriteLine("Inserarea a esuat.");
                    }
                }
            }
        }


    }
}
