﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace DB_dll.Tables
{
    internal class TasksType : Tabel
    {
        public int ID {  get; }
        public string Name { get; set; }
        public string Description { get; set; }
        public TasksType(string mName,string mDescription) 
        {
            Name = mName;
            Description = mDescription;
        }
    }
}
