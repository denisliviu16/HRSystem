﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace DB_dll.Tables
{
    internal class ProjectsDuties : Tabel
    {
        public int ID {  get; }
        public int ProjectID { get; set; }

        public int EmployeeID {  get; set; }

        public ProjectsDuties(int mProjectID,int mEmployeeID)
        {
            ProjectID = mProjectID;
            EmployeeID = mEmployeeID; 
  
        }


    }
}
