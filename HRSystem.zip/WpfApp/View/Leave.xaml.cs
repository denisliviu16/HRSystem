﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;

namespace TCPClient.View
{
    /// <summary>
    /// Interaction logic for Leave.xaml
    /// </summary>
    public partial class Leave : UserControl
    {
        public Leave()
        {
            InitializeComponent();
        }

        private void Search_here_GotFocus(object sender, RoutedEventArgs e)
        {
            if (Search_here.Text.ToString() == "Search here ...")
            {
                Search_here.Text = "";
            }
        }

        private void Search_here_LostFocus(object sender, RoutedEventArgs e)
        {
            if (string.IsNullOrWhiteSpace(Search_here.Text.ToString()))
            {
                Search_here.Text = "Search here ...";
            }
        }

        private void searching_box_GotFocus(object sender, RoutedEventArgs e)
        {
            if (searching_box.Text.ToString() == "Search in Holidays List ...")
            {
                searching_box.Text = "";
            }
        }

        private void searching_box_LostFocus(object sender, RoutedEventArgs e)
        {
            if (string.IsNullOrWhiteSpace(searching_box.Text.ToString()))
            {
                searching_box.Text = "Search in Holidays List ...";
            }
        }

        private void searching_box2_GotFocus(object sender, RoutedEventArgs e)
        {
            if (searching_box2.Text.ToString() == "Search in Application List ...")
            {
                searching_box2.Text = "";
            }
        }

        private void searching_box2_LostFocus(object sender, RoutedEventArgs e)
        {
            if (string.IsNullOrWhiteSpace(searching_box2.Text.ToString()))
            {
                searching_box2.Text = "Search in Application List ...";
            }
        }

        private void searching_box3_GotFocus(object sender, RoutedEventArgs e)
        {
            if (searching_box3.Text.ToString() == "Search in Purpose Leaving List ...")
            {
                searching_box3.Text = "";
            }
        }

        private void searching_box3_LostFocus(object sender, RoutedEventArgs e)
        {
            if (string.IsNullOrWhiteSpace(searching_box3.Text.ToString()))
            {
                searching_box3.Text = "Search in Purpose Leaving List ...";
            }
        }
    }
}
