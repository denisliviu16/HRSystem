﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;

namespace TCPClient.View
{
    /// <summary>
    /// Interaction logic for Attendance.xaml
    /// </summary>
    public partial class Attendance : UserControl
    {
        public Attendance()
        {
            InitializeComponent();


            var converter = new BrushConverter();

            Meeting firstEmployee = new Meeting();
            firstEmployee.Number = "1";
            firstEmployee.Character = "D";
            firstEmployee.BgColor = (Brush)converter.ConvertFromString("#1098ad");
            firstEmployee.Employeer = "Denis Iana";
            firstEmployee.Pin = "1234";
            firstEmployee.SignIn = "08:00";
            firstEmployee.SignOut = "14:00";
            firstEmployee.WorkHour = "6";
            firstEmployee.Date = "04.11.2023";

            employeesDataGrid.Items.Add(firstEmployee);

        }

        private void Search_here_GotFocus(object sender, RoutedEventArgs e)
        {
            if (Search_here.Text.ToString() == "Search here ...")
            {
                Search_here.Text = "";
            }
        }

        private void Search_here_LostFocus(object sender, RoutedEventArgs e)
        {
            if (string.IsNullOrWhiteSpace(Search_here.Text.ToString()))
            {
                Search_here.Text = "Search here ...";
            }
        }
    }

    public class Meeting
    {
        public string Employeer { get; set; }
        public string Pin { get; set; }
        public string Date { get; set; }
        public string SignIn { get; set; }

        public string SignOut { get; set; }

        public string WorkHour { get; set; }

        public string Character { get; set; }

        public Brush BgColor { get; set; }
        public string Number { get; set; }
    }
}
