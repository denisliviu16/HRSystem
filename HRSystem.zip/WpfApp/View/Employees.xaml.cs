﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;
using System.Collections.ObjectModel;

namespace TCPClient.View
{
    /// <summary>
    /// Interaction logic for Employees.xaml
    /// </summary>
    public partial class Employees : UserControl
    {
        public Employees()
        {
            InitializeComponent();

            var converter = new BrushConverter();

            Employee firstEmployee = new Employee();
            firstEmployee.Number = "1";
            firstEmployee.Character = "D";
            firstEmployee.BgColor = (Brush)converter.ConvertFromString("#1098ad");
            firstEmployee.Employeer = "Denis Iana";
            firstEmployee.Position = "Coach";
            firstEmployee.Email = "denis_liviu2000@yahoo.com";
            firstEmployee.Phone = "+40731201587";

            Employee secondEmployee = new Employee();
            secondEmployee.Number = "2";
            secondEmployee.Character = "M";
            secondEmployee.BgColor = (Brush)converter.ConvertFromString("#1e88e5");
            secondEmployee.Employeer = "Lionel Messi";
            secondEmployee.Position = "Coach";
            secondEmployee.Email = "leo_messi10@yahoo.com";
            secondEmployee.Phone = "+40729861249";


            employeesDataGrid.Items.Add(firstEmployee);
            employeesDataGrid.Items.Add(secondEmployee);

        }

        private void employeesDataGrid_SelectionChanged(object sender, SelectionChangedEventArgs e)
        {

        }


        private void searching_box_GotFocus(object sender, RoutedEventArgs e)
        {
            if (searching_box.Text.ToString() == "Search in Employees ...")
            {
                searching_box.Text = "";
            }
        }

        private void searching_box_LostFocus(object sender, RoutedEventArgs e)
        {
            if (string.IsNullOrWhiteSpace(searching_box.Text.ToString()))
            {
                searching_box.Text = "Search in Employees ...";
            }
        }

        private void Search_here_GotFocus(object sender, RoutedEventArgs e)
        {
            if (Search_here.Text.ToString() == "Search here ...")
            {
                Search_here.Text = "";
            }
        }

        private void Search_here_LostFocus(object sender, RoutedEventArgs e)
        {
            if (string.IsNullOrWhiteSpace(Search_here.Text.ToString()))
            {
                Search_here.Text = "Search here ...";
            }
        }
    }

    public class Employee
    {
        public string Employeer { get; set; }
        public string Position { get; set; }
        public string Email { get; set; }
        public string Phone { get; set; }

        public string Character { get; set; }
    
        public Brush BgColor { get; set; }
        public string Number { get; set; }
    }

}
