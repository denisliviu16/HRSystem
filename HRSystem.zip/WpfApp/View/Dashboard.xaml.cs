﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;

namespace TCPClient.View
{
    /// <summary>
    /// Interaction logic for Dashboard.xaml
    /// </summary>
    public partial class Dashboard : UserControl
    {
        public Dashboard()
        {
            InitializeComponent();
        }

        private void Search_here_GotFocus(object sender, RoutedEventArgs e)
        {
            if (Search_here.Text.ToString() == "Search here ...")
            {
                Search_here.Text = "";
            }
        }

        private void Search_here_LostFocus(object sender, RoutedEventArgs e)
        {
            if (string.IsNullOrWhiteSpace(Search_here.Text.ToString()))
            {
                Search_here.Text = "Search here ...";
            }
        }

        private void employees_MouseEnter(object sender, MouseEventArgs e)
        {
            employees.Background = new SolidColorBrush((Color)ColorConverter.ConvertFromString("#6741d9"));
            first_box.Foreground = new SolidColorBrush(Colors.White);
        }

        private void employees_MouseLeave(object sender, MouseEventArgs e)
        {
            employees.Background = new SolidColorBrush(Colors.White);
            first_box.Foreground = new SolidColorBrush((Color)ColorConverter.ConvertFromString("#222528"));

        }

        private void Grid_MouseEnter(object sender, MouseEventArgs e)
        {
            projects.Background = new SolidColorBrush((Color)ColorConverter.ConvertFromString("#6741d9"));
            second_box.Foreground = new SolidColorBrush(Colors.White);
        }

        private void Grid_MouseLeave(object sender, MouseEventArgs e)
        {
            projects.Background = new SolidColorBrush(Colors.White);
            second_box.Foreground = new SolidColorBrush((Color)ColorConverter.ConvertFromString("#222528"));
        }

        private void leaves_MouseEnter(object sender, MouseEventArgs e)
        {
            leaves.Background = new SolidColorBrush((Color)ColorConverter.ConvertFromString("#6741d9"));
            third_box.Foreground = new SolidColorBrush(Colors.White);
        }

        private void leaves_MouseLeave(object sender, MouseEventArgs e)
        {
            leaves.Background = new SolidColorBrush(Colors.White);
            third_box.Foreground = new SolidColorBrush((Color)ColorConverter.ConvertFromString("#222528"));
        }

        private void searching_box_GotFocus(object sender, RoutedEventArgs e)
        {
            if (searching_box.Text.ToString() == "Search in Projects ...")
            {
                searching_box.Text = "";
            }
        }

        private void searching_box_LostFocus(object sender, RoutedEventArgs e)
        {
            if (string.IsNullOrWhiteSpace(searching_box.Text.ToString()))
            {
                searching_box.Text = "Search in Projects ...";
            }
        }
    }
}
