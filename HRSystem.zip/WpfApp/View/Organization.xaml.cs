﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;

namespace TCPClient.View
{
    /// <summary>
    /// Interaction logic for Organization.xaml
    /// </summary>
    public partial class Organization : UserControl
    {
        public Organization()
        {
            InitializeComponent();
        }

        private void searching_box_GotFocus(object sender, RoutedEventArgs e)
        {
            if (searching_box.Text.ToString() == "Search in Department List ...")
            {
                searching_box.Text = "";
            }
        }

        private void searching_box_LostFocus(object sender, RoutedEventArgs e)
        {
            if (string.IsNullOrWhiteSpace(searching_box.Text.ToString()))
            {
                searching_box.Text = "Search in Department List ...";
            }
        }

        private void Search_here_GotFocus(object sender, RoutedEventArgs e)
        {
            if (Search_here.Text.ToString() == "Search here ...")
            {
                Search_here.Text = "";
            }
        }

        private void Search_here_LostFocus(object sender, RoutedEventArgs e)
        {
            if (string.IsNullOrWhiteSpace(Search_here.Text.ToString()))
            {
                Search_here.Text = "Search here ...";
            }
        }
    }
}
