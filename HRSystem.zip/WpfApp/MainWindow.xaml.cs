﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;
using SuperSimpleTcp;
using System.Net.Security;

namespace TCPClient
{
    /// <summary>
    /// Interaction logic for MainWindow.xaml
    /// </summary>
    public partial class MainWindow : Window
    {
        public MainWindow()
        {
            InitializeComponent();

            Icon = new BitmapImage(new Uri("C:/Users/Denis/Desktop/Aplicatii - Baze de date/WpfApp/Images/logo.png"));
            Loaded += Window_Loaded;
        }

        SimpleTcpClient client;

        private void Send_Click(object sender, RoutedEventArgs e)
        {
            PageNavigation pageWindow = new PageNavigation();
            this.Close();
            pageWindow.Show();

            /*
            if (!client.IsConnected)
            {
                client.Connect();
            }

            if (client.IsConnected)
            {

                if (!string.IsNullOrEmpty(txtUsername.Text) && !string.IsNullOrEmpty(txtPassword.Password))
                {
                    string comanda = "ComandaB:" + txtUsername.Text + ":" + txtPassword.Password;

                    client.Send(comanda);

                    txtUsername.Text = string.Empty;
                    txtPassword.Password = string.Empty;
                }
            }*/
        }


        private void Window_Loaded(object sender,RoutedEventArgs e)
        {
            client = new SimpleTcpClient("127.0.0.1:9000");
            client.Events.Connected += Events_Connected;
            client.Events.DataReceived += Events_DataReceived;
            client.Events.Disconnected += Events_Disconnected;
        }

        private void Events_Disconnected(object sender, ConnectionEventArgs e)
        {
        }

        private void Events_DataReceived(object sender, DataReceivedEventArgs e)
        {
        }

        private void Events_Connected(object sender, ConnectionEventArgs e)
        {
            //Application.Current.Dispatcher.Invoke(() =>
            //{
            //});
        }

        private void txtUsername_GotFocus(object sender, RoutedEventArgs e)
        {
            if (txtUsername.Text == "username")
            {
                txtUsername.Text = string.Empty;
            }
        }

        private void txtPassword_GotFocus(object sender, RoutedEventArgs e)
        {
            if(txtPassword.Password == "password")
            {
                txtPassword.Password = string.Empty;
            }
        }

        public void Window_MouseDown(object sender, MouseButtonEventArgs e)
        {
            if(e.LeftButton == MouseButtonState.Pressed)
            {
                DragMove();
            }
        }

        private void Button_Click(object sender, RoutedEventArgs e)
        {
            RegisterWindow secondWindow = new RegisterWindow();
            this.Close();
            secondWindow.Show();
        }

        private void txtUsername_LostFocus(object sender, RoutedEventArgs e)
        {
            if (string.IsNullOrWhiteSpace(txtUsername.Text))
            {
                txtUsername.Text = "username";
            }
        }

        private void txtPassword_LostFocus(object sender, RoutedEventArgs e)
        {
            if (string.IsNullOrWhiteSpace(txtPassword.Password))
            {
                txtPassword.Password = "password";
            }
        }
    }
}
