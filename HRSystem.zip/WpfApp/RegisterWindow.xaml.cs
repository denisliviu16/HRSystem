﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Shapes;

namespace TCPClient
{
    /// <summary>
    /// Interaction logic for RegisterWindow.xaml
    /// </summary>
    public partial class RegisterWindow : Window
    {
        public string[] BloodGroups { get; set; }
        public string[] Genders { get; set; }
        public RegisterWindow()
        {
            InitializeComponent();
            Icon = new BitmapImage(new Uri("C:/Users/Denis/Desktop/Aplicatii - Baze de date/WpfApp/Images/logo.png"));
            BloodGroups = new string[] { "O-", "O+", "A-", "A+", "B-", "B+", "AB-", "AB+" };
            Genders = new string[] { "Male", "Female" };
            DataContext = this;
        }

        private void FirstNameTestBox_GotFocus(object sender, RoutedEventArgs e)
        {
            if (FirstNameTestBox.Text == "first name")
            {
                FirstNameTestBox.Text = "";
            }
        }

        private void FirstNameTestBox_LostFocus(object sender, RoutedEventArgs e)
        {
            if (string.IsNullOrWhiteSpace(FirstNameTestBox.Text))
            {
                FirstNameTestBox.Text = "first name";
            }
        }

        private void LastName_GotFocus(object sender, RoutedEventArgs e)
        {
            if (LastName.Text == "last name")
            {
                LastName.Text = "";
            }
        }

        private void LastName_LostFocus(object sender, RoutedEventArgs e)
        {
            if (string.IsNullOrWhiteSpace(LastName.Text))
            {
                LastName.Text = "last name";
            }
        }

        private void EmailTextBox_GotFocus(object sender, RoutedEventArgs e)
        {
            if (EmailTextBox.Text == "email")
            {
                EmailTextBox.Text = "";
            }
        }

        private void EmailTextBox_LostFocus(object sender, RoutedEventArgs e)
        {
            if (string.IsNullOrWhiteSpace(EmailTextBox.Text))
            {
                EmailTextBox.Text = "email";
            }
        }

        private void ContactNumberTexBox_GotFocus(object sender, RoutedEventArgs e)
        {
            if (ContactNumberTexBox.Text == "contact number")
            {
                ContactNumberTexBox.Text = "";
            }
        }

        private void ContactNumberTexBox_LostFocus(object sender, RoutedEventArgs e)
        {
            if (string.IsNullOrWhiteSpace(ContactNumberTexBox.Text))
            {
                ContactNumberTexBox.Text = "contact number";
            }
        }

        private void Country_GotFocus(object sender, RoutedEventArgs e)
        {
            if (Country.Text == "country")
            {
                Country.Text = "";
            }
        }

        private void Country_LostFocus(object sender, RoutedEventArgs e)
        {
            if (string.IsNullOrWhiteSpace(Country.Text))
            {
                Country.Text = "country";
            }
        }

        private void City_GotFocus(object sender, RoutedEventArgs e)
        {
            if (City.Text == "city")
            {
                City.Text = "";
            }
        }

        private void City_LostFocus(object sender, RoutedEventArgs e)
        {
            if (string.IsNullOrWhiteSpace(City.Text))
            {
                City.Text = "city";
            }
        }

        private void Street_GotFocus(object sender, RoutedEventArgs e)
        {
            if (Street.Text == "street")
            {
                Street.Text = "";
            }
        }

        private void Street_LostFocus(object sender, RoutedEventArgs e)
        {
            if (string.IsNullOrWhiteSpace(Street.Text))
            {
                Street.Text = "street";
            }
        }

        private void Username_GotFocus(object sender, RoutedEventArgs e)
        {
            if (Username.Text == "username")
            {
                Username.Text = "";
            }
        }

        private void Username_LostFocus(object sender, RoutedEventArgs e)
        {
            if (string.IsNullOrWhiteSpace(Username.Text))
            {
                Username.Text = "username";
            }
        }

        private void Password_GotFocus(object sender, RoutedEventArgs e)
        {
            if (Password.Password == "password")
            {
                Password.Password = "";
            }
        }

        private void Password_LostFocus(object sender, RoutedEventArgs e)
        {
            if (string.IsNullOrWhiteSpace(Password.Password))
            {
                Password.Password = "password";
            }
        }

        private void PasswordControl_GotFocus(object sender, RoutedEventArgs e)
        {
            if (PasswordControl.Password == "confirm password")
            {
                PasswordControl.Password = "";
            }
        }

        private void PasswordControl_LostFocus(object sender, RoutedEventArgs e)
        {
            if (string.IsNullOrWhiteSpace(PasswordControl.Password))
            {
                PasswordControl.Password = "confirm password";
            }
        }

        private void Button_Click(object sender, RoutedEventArgs e)
        {
            MainWindow main_Window = new MainWindow();
            this.Close();
            main_Window.Show();
        }

        private void Window_MouseDown(object sender, MouseButtonEventArgs e)
        {

        }
    }
}
