﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using TCPClient.Utilities;
using System.Windows.Input;

namespace TCPClient.ViewModel
{
    class NavigationVM : ViewModelBase
    {
        private object _currentView;
        public object CurrentView
        {
            get { return _currentView; }
            set { _currentView = value; OnPropertyChanged(); }
        }

        public ICommand HomeCommand { get; set; }
        public ICommand AssetsCommand { get; set; }
        public ICommand AttendanceCommand { get; set; }

        public ICommand DashboardCommand { get; set; }

        public ICommand EmployeesCommand { get; set; }

        public ICommand LeaveCommand { get; set; }

        public ICommand OrganizationCommand { get; set; }

        public ICommand PayrollCommand { get; set; }

        public ICommand ProjectCommand { get; set; }


        private void Home(object obj) => CurrentView = new HomeVM();
        private void Assets(object obj) => CurrentView = new AssetsVM();

        private void Attendance(object obj) => CurrentView = new AttendanceVM();

        private void Dashboard(object obj) => CurrentView = new DashboardVM();

        private void Employees(object obj) => CurrentView = new EmployeesVM();

        private void Leave(object obj) => CurrentView = new LeaveVM();

        private void Organization(object obj) => CurrentView = new OrganizationVM();

        private void Payroll(object obj) => CurrentView = new PayrollVM();

        private void Project(object obj) => CurrentView = new ProjectVM();

        public NavigationVM()
        {
            HomeCommand = new RelayCommand(Home);
            AssetsCommand = new RelayCommand(Assets);
            AttendanceCommand = new RelayCommand(Attendance);
            DashboardCommand = new RelayCommand(Dashboard);
            EmployeesCommand = new RelayCommand(Employees);
            LeaveCommand = new RelayCommand(Leave);
            OrganizationCommand = new RelayCommand(Organization);
            PayrollCommand = new RelayCommand(Payroll);
            ProjectCommand = new RelayCommand(Project);
            // Startup Page
            CurrentView = new HomeVM();
        }
    }
}
