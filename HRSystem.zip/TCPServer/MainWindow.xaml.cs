﻿using SuperSimpleTcp;
using System.Windows.Threading;
using System;
using System.Collections.Generic;
using System.Globalization;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;

namespace TCPServer
{
    /// <summary>
    /// Interaction logic for MainWindow.xaml
    /// </summary>
    public partial class MainWindow : Window
    {
        public MainWindow()
        {
            InitializeComponent();
            Loaded += Window_Loaded;
        }

        SimpleTcpServer server;

        private void Window_Loaded(object sender,RoutedEventArgs e)
        {
            Send.IsEnabled = false;
            server = new SimpleTcpServer(txtIP.Text);
            server.Events.ClientConnected += Events_ClientConnected;
            server.Events.ClientDisconnected += Events_ClientDisconnected;
            server.Events.DataReceived += Events_DataReceived;
        }

        private void Button_Click(object sender, RoutedEventArgs e)
        {
            if (server != null)
            {
                server.Start();
                txtInfo.Text += $"Starting...{Environment.NewLine}";
                Start.IsEnabled = false;
                Send.IsEnabled = true;
            }
            else
            {
                MessageBox.Show("Server is not initialized. Please make sure it's properly configured.");
            }
        }

        private void Events_DataReceived(object sender, DataReceivedEventArgs e)
        {
            Application.Current.Dispatcher.Invoke(() =>
            {
                string receivedData = Encoding.UTF8.GetString(e.Data.Array);
                if (receivedData.StartsWith("ComandaA:"))
                {
                    receivedData = receivedData.Replace("ComandaA:", "");
                    txtInfo.Text += $"{e.IpPort}: {receivedData}{Environment.NewLine}";
                }
                else if (receivedData.StartsWith("ComandaB:"))
                {
                    receivedData = receivedData.Replace("ComandaB:", "");
                    string[] parts = receivedData.Split(':');
                    txtInfo.Text += $"{e.IpPort}: Username : {parts[0]}{Environment.NewLine}";
                    txtInfo.Text += $"{e.IpPort}: Password : {parts[1]}{Environment.NewLine}";
                }
            });
        }

        private void Events_ClientDisconnected(object sender, ConnectionEventArgs e)
        {
            Application.Current.Dispatcher.Invoke(() =>
            {
                txtInfo.Text += $"{e.IpPort} disconnected.{Environment.NewLine}";
                lstClientIP.Items.Remove(e.IpPort);
            });
        }

        private void Events_ClientConnected(object sender, ConnectionEventArgs e)
        {
            Application.Current.Dispatcher.Invoke(() =>
            {
                txtInfo.Text += $"{e.IpPort} connected.{Environment.NewLine}";
                lstClientIP.Items.Add(e.IpPort);
            });
        }

        private void Send_Click(object sender, RoutedEventArgs e)
        {
            if(server.IsListening)
            {
                if(!string.IsNullOrEmpty(txtMessage.Text)&&lstClientIP.SelectedItem!=null)
                {
                    server.Send(lstClientIP.SelectedItem.ToString(), txtMessage.Text);
                    txtInfo.Text += $"Server:{txtMessage.Text}{Environment.NewLine}";
                    txtMessage.Text = string.Empty;
                }
            }
        }
    }
}
